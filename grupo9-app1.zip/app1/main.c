#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include <stdlib.h>
#include "Libros.h"
#include "Utils.h"

//contratos
void closeProgram();
void showMenu();
void keepGoing();

//Variables
//Defino la estructura que usare para guardar los contenidos en memoria
char *filename;

FILE * openFileToRead(char *filename){
    FILE *fp;
    fp = fopen(filename,"r");
    return fp;
}

FILE * openFileToWrite(char *filename){
    FILE *fp;
    fp = fopen(filename,"w");
    return fp;
}

//metodo principal
int main(int argc, char *argv[] ){

    //Abro el archivo
    filename = argv[1];
    FILE *fp = openFileToRead(filename);
    //paso el contenido del file a un array de personas
    libros = getLibros(fp);
    //cierro el archivo.
    fclose(fp);
    //Cargo la estructura
    showMenu();
    return 0;

}

void showTitles(){
    printf("Lista de acciones disponibles: \n \t "
           "1. Agregar libro. \n \t 2. Eliminar libro. \n \t"
           "3. Editar un título, sección, sede o piso.\n \t 4. Eliminar una sección.\n \t"
           " 5. Agregar una sección.\n \t 6. Eliminar una sede.\n \t "
           "7. Agregar una sede.\n \t 8. Buscar un libro. \n \t 9. Salir del menú. \n ¿Que opcion desea? (Ingrese un número): " );
}
void showMenu(){
    int option = 0;
    showTitles();
    scanf("%d", &option);
    //esto hace que el menu vuelva a mostrarse hasta que me ingrese una opcion valida

    //Solo salgo con una opcion valida
    switch (option) {
        case 1: //agregar libro
            agregarLibros();
            //al terminar muestro el menu de nuevo;
            keepGoing();
            break;
        case 2: //eliminar libro
            eliminarLibro();
            //al terminar muestro el menu de nuevo;
            keepGoing();
            break;

        case 3:
            editarLibro();
            //al terminar muestro el menu de nuevo;
            keepGoing();
            break;
        case 4:
            eliminarSeccion();
            //al terminar muestro el menu de nuevo;
            keepGoing();
            break;
        case 5:
            agregarSeccion();
            //al terminar muestro el menu de nuevo;
            keepGoing();
            break;
        case 6:
            eliminarSede();
            //al terminar muestro el menu de nuevo;
            keepGoing();
            break;
        case 7:
            agregarSede();
            //al terminar muestro el menu de nuevo;
            keepGoing();
            break;
        case 8:
            mostrarLibros();
            //al terminar muestro el menu de nuevo;
            keepGoing();
            break;
        case 9:
            closeProgram();
            break;
    }
}

void keepGoing() {
    //verifico que el usuario quiera seguir o closeProgram
    printf("Desea realizar una nueva acción? Presione S o cualquier otra tecla para cerarr el programa.");
    char *rta = (char*)malloc(1 * sizeof(char));
    scanf("%s", rta);
    //Verifico que pueda closeProgram.
    if (strcmp(rta, "s") == 0){
        //muestro menu
        showMenu();
    } else {
        closeProgram();
    }
}



void closeProgram() {
    printf("Gracias por usar el programa \n");
    //ahora hago el proceso inverso y finalmente copio todo de nuevo al archivo
    FILE *fp = openFileToWrite(filename);
    writeLibros(libros, fp);
    fclose(fp);
}
