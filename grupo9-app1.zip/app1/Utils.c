#include <stdlib.h>
#include <strings.h>
#include <ctype.h>
#include "Utils.h"

char *toLowerC(char *name) {
    char *converted =  (char*)malloc( strlen(name) * sizeof(char));
    strcpy(converted,name);
    for(int i = 0; converted[i]; i++){
        converted[i] = tolower(converted[i]);
    }
    return converted;
}